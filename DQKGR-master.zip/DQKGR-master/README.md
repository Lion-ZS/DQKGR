# Dual Quaternion Based Collaborative Knowledge Graph Modeling for Recommendation

>  Zongsheng Cao, Qianqian Xu, Zhaopeng Li, Yangbangyan Jiang, Xiaochun Cao and Qingming Huang. Dual Quaternion Based Collaborative Knowledge Graph Modeling for Recommendation. Chinese Journal of Computers 2022.

This is an official implementation with Tensorflow, and we run our code on Ubuntu 16.04.1 server. More experimental details can be found in our paper.

## Dependencies
All the experiments are carried out on a ubuntu 16.04.1 server equipped with Intel(R) Xeon(R) Silver 4110 CPU and a TITAN RTX GPU. In addition, our experiments require
- python 3.6.5
- tensorflow 1.12.0
- numpy 1.15.4
- scipy 1.1.0
- sklearn 0.20.0

## Datasets

In our paper, we evaluate our proposed method on three benchmark datasets, which can be downloaded from https://drive.google.com/file/d/1RYXrEnPIhOlVUWksLFVTdwlSBmiRkVql/view?usp=sharing, including:
- Last-fm: included in DQKGR-master/Data
- MovieLens-20M: included in DQKGR-master/Data
- Book-crossing: included in DQKGR-master/Data

Moreover, there are three sub-datasets in each dataset, including training, valid and test datasets.

## How to Run
- First of all, you need to install the dependencies by 
```
pip3 install -r requirements.txt
```
- Then to preprocess the datasets, run the following commands.
```
unzip Data.zip
```

Subsequently, you can obtain all results on each datasets:
```bash
Last-fm
python3 -u Main_DR.py  --dataset last-fm --lr 0.001 --epoch 1000 --verbose 50 --embed_size 64 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 4 --initial 1 --normal_r 2 --bi_type 1

MovieLens-20M
python3 -u Main_DR.py  --dataset movie --lr 5e-4 --epoch 1000 --verbose 50 --embed_size 96 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 2 --initial 1 --normal_r 2 --reg1 1.5 --reg2 1e-3 --bi_type 0 --user_num 10000 --pretrain -1

Book-crossing
python3 -u Main_DR.py  --dataset bookcx --pretrain -1 --lr 5e-4 --epoch 1000 --verbose 50 --embed_size 16 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 3 --initial 1 --normal_r 2 --reg1 1e-1 --reg2 1e-4 --bi_type 1
```
