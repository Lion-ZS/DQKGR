###DQKGR 
* Last-fm
  
>python3 -u Main_DR.py  --dataset last-fm --lr 0.001 --epoch 1000 --verbose 50 --embed_size 32 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 4 --initial 1 --normal_r 2 --bi_type 1

* MovieLens-20M
  
>python3 -u Main_DR.py  --dataset movie --lr 5e-4 --epoch 1000 --verbose 50 --embed_size 64 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 3 --initial 1 --normal_r 2 --reg1 1.5 --reg2 1e-3 --bi_type 1 --user_num 10000

* Book-crossing

>python3 -u Main_DR.py  --dataset bookcx --pretrain -1 --lr 5e-4 --epoch 1000 --verbose 50 --embed_size 32 --node_dropout [0.1] --mess_dropout [0.1,0.1,0.1] --layer_size [] --use_att 1 --use_kge 1 --early_stop 50 --gpu_id 2 --initial 1 --normal_r 2 --reg1 1e-1 --reg2 1e-4 --bi_type 1





